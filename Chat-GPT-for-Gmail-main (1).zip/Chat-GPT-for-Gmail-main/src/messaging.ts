export interface Answer {
  text: string
  messageId: string
  conversationId: string
}
