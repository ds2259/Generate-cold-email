import { render } from 'preact'
import Options from './Options'

render(<Options />, document.getElementById('app'))
