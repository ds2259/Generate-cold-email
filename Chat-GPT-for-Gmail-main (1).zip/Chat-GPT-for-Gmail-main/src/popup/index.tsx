import { render } from 'preact'
import Popup from './Popup'

render(<Popup />, document.getElementById('app'))
